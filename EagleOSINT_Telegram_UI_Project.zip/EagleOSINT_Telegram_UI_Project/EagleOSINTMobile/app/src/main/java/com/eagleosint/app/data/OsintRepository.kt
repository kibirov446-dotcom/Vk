package com.eagleosint.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class ScanResultItem(
    val platform: String,
    val url: String,
    val status: String,
    val found: Boolean
)

class OsintRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val platforms = mapOf(
        "GitHub" to "https://github.com/%s",
        "Reddit" to "https://www.reddit.com/user/%s",
        "GitLab" to "https://gitlab.com/%s",
        "Habr" to "https://habr.com/ru/users/%s/",
        "Medium" to "https://medium.com/@%s",
        "Dev.to" to "https://dev.to/%s",
        "Pinterest" to "https://www.pinterest.com/%s/",
        "Twitch" to "https://www.twitch.tv/%s",
        "Steam" to "https://steamcommunity.com/id/%s",
        "Telegram" to "https://t.me/%s"
    )

    fun checkUsername(username: String): Flow<ScanResultItem> = flow {
        val cleanUser = username.trim()
        for ((name, template) in platforms) {
            val url = String.format(template, cleanUser)
            val result = try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 17) AppleWebKit/537.36")
                    .build()
                client.newCall(request).execute().use { response ->
                    val isFound = response.code == 200
                    ScanResultItem(
                        platform = name,
                        url = url,
                        status = if (isFound) "Профиль найден (HTTP 200)" else "Не найдено (${response.code})",
                        found = isFound
                    )
                }
            } catch (e: Exception) {
                ScanResultItem(
                    platform = name,
                    url = url,
                    status = "Ошибка сети: ${e.localizedMessage ?: "таймаут"}",
                    found = false
                )
            }
            emit(result)
        }
    }.flowOn(Dispatchers.IO)

    fun generateDorks(target: String): List<ScanResultItem> {
        val encoded = URLEncoder.encode(target.trim(), "UTF-8")
        val queries = listOf(
            "Упоминания в соцсетях" to "https://www.google.com/search?q=%22$encoded%22+site:linkedin.com+OR+site:github.com",
            "Публичные документы (PDF/DOC)" to "https://www.google.com/search?q=%22$encoded%22+filetype:pdf+OR+filetype:docx",
            "Открытые репозитории и Gist" to "https://www.google.com/search?q=%22$encoded%22+site:gist.github.com+OR+site:pastebin.com",
            "Индексация на форумах" to "https://www.google.com/search?q=%22$encoded%22+inurl:profile+OR+inurl:user"
        )
        return queries.map { (title, url) ->
            ScanResultItem(
                platform = title,
                url = url,
                status = "Готовый поисковый запрос",
                found = true
            )
        }
    }
}
