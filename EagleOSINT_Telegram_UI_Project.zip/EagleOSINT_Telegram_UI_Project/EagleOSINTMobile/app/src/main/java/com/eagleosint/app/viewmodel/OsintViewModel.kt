package com.eagleosint.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eagleosint.app.data.OsintRepository
import com.eagleosint.app.data.ScanResultItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ScanUiState(
    val isScanning: Boolean = false,
    val progress: Float = 0f,
    val results: List<ScanResultItem> = emptyList(),
    val statusMessage: String = "Введите цель для начала разведки"
)

class OsintViewModel : ViewModel() {
    private val repository = OsintRepository()
    private val _uiState = MutableStateFlow(ScanUiState())
    val uiState: StateFlow<ScanUiState> = _uiState.asStateFlow()

    private var scanJob: Job? = null

    fun startScan(moduleRoute: String, target: String) {
        if (target.isBlank()) return
        scanJob?.cancel()
        _uiState.value = ScanUiState(
            isScanning = true,
            progress = 0.05f,
            results = emptyList(),
            statusMessage = "Запуск модуля сканирования..."
        )

        scanJob = viewModelScope.launch {
            if (moduleRoute == "godorker") {
                val dorks = repository.generateDorks(target)
                _uiState.value = ScanUiState(
                    isScanning = false,
                    progress = 1f,
                    results = dorks,
                    statusMessage = "Сгенерировано ${dorks.size} поисковых запросов"
                )
            } else {
                val collected = mutableListOf<ScanResultItem>()
                val totalPlatforms = 10f
                repository.checkUsername(target).collect { item ->
                    collected.add(item)
                    _uiState.value = ScanUiState(
                        isScanning = collected.size < totalPlatforms.toInt(),
                        progress = collected.size / totalPlatforms,
                        results = collected.toList(),
                        statusMessage = "Проверено ${collected.size} из ${totalPlatforms.toInt()} платформ"
                    )
                }
            }
        }
    }

    fun clearResults() {
        scanJob?.cancel()
        _uiState.value = ScanUiState()
    }
}
