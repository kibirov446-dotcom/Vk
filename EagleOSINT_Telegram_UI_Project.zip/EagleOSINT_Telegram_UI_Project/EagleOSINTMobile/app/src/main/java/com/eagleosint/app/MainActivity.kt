package com.eagleosint.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.eagleosint.app.ui.screens.DashboardScreen
import com.eagleosint.app.ui.screens.OsintModule
import com.eagleosint.app.ui.screens.ScanScreen
import com.eagleosint.app.ui.theme.EagleOSINTTheme
import com.eagleosint.app.viewmodel.OsintViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EagleOSINTTheme {
                val viewModel: OsintViewModel = viewModel()
                var selectedModule by remember { mutableStateOf<OsintModule?>(null) }

                if (selectedModule == null) {
                    DashboardScreen(onModuleClick = { selectedModule = it })
                } else {
                    ScanScreen(
                        module = selectedModule!!,
                        viewModel = viewModel,
                        onBack = { selectedModule = null }
                    )
                }
            }
        }
    }
}
