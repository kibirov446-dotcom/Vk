package com.eagleosint.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Telegram-inspired Color Palette (Classic Blue theme)
private val TelegramBlue = Color(0xFF2481CC)
private val TelegramBlueDark = Color(0xFF17212B)
private val TelegramDarkBackground = Color(0xFF0E1621)
private val TelegramDarkSurface = Color(0xFF18222D)
private val TelegramDarkCard = Color(0xFF1F2936)

private val TelegramLightBackground = Color(0xFFF1F1F1)
private val TelegramLightSurface = Color(0xFFFFFFFF)
private val TelegramLightCard = Color(0xFFF7F8F9)

private val DarkColorScheme = darkColorScheme(
    primary = TelegramBlue,
    onPrimary = Color.White,
    primaryContainer = TelegramDarkCard,
    onPrimaryContainer = Color(0xFF85B8EE),
    secondary = Color(0xFF5382A1),
    background = TelegramDarkBackground,
    surface = TelegramDarkSurface,
    surfaceContainerHigh = TelegramDarkCard,
    onSurface = Color(0xFFF5F5F5),
    onSurfaceVariant = Color(0xFF8A9BA8)
)

private val LightColorScheme = lightColorScheme(
    primary = TelegramBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EDF7),
    onPrimaryContainer = Color(0xFF1C6399),
    secondary = Color(0xFF3390EC),
    background = TelegramLightBackground,
    surface = TelegramLightSurface,
    surfaceContainerHigh = TelegramLightCard,
    onSurface = Color(0xFF222222),
    onSurfaceVariant = Color(0xFF707579)
)

@Composable
fun EagleOSINTTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Отключаем по умолчанию чтобы сохранить фирменный стиль Telegram
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}
