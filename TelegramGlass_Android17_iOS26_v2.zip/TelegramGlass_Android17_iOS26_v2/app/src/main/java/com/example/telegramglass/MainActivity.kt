package com.example.telegramglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            TelegramGlassTheme {
                TelegramGlassApp()
            }
        }
    }
}

@Composable
fun TelegramGlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF3390EC),
            background = Color(0xFF0A0F1C),
            surface = Color(0xFF141E30)
        ),
        content = content
    )
}

// Модели данных
data class ChatPreview(
    val id: String,
    val title: String,
    val subtitle: String,
    val time: String,
    val unreadCount: Int,
    val avatarColor: List<Color>,
    val initials: String
)

data class ChatMessage(
    val id: String,
    val text: String,
    val time: String,
    val isMine: Boolean
)

val sampleChats = listOf(
    ChatPreview("1", "OSINT Hub", "Новый дамп инструментов в репозитории", "14:20", 3, listOf(Color(0xFF00C6FF), Color(0xFF0072FF)), "OH"),
    ChatPreview("2", "Алексей (Design)", "Посмотри новые iOS 26 liquid glass переходы", "13:05", 0, listOf(Color(0xFFF857A6), Color(0xFFFF5858)), "АД"),
    ChatPreview("3", "Избранное", "Заметки по проекту Android 17", "Вчера", 0, listOf(Color(0xFF43E97B), Color(0xFF38F9D7)), "★"),
    ChatPreview("4", "Mobile Dev Club", "Jetpack Compose + RenderEffect на максимуме", "Пн", 12, listOf(Color(0xFFFA709A), Color(0xFFFEE140)), "MD"),
    ChatPreview("5", "Кибербезопасность", "Обновление протоколов шифрования", "Вс", 1, listOf(Color(0xFF667EEA), Color(0xFF764BA2)), "КБ"),
    ChatPreview("6", "Дизайн-система", "Спецификации прозрачности и бликов", "Сб", 0, listOf(Color(0xFF11998E), Color(0xFF38EF7D)), "ДС"),
    ChatPreview("7", "Linux & Kernel", "Сборка ядра и оптимизация", "Пт", 4, listOf(Color(0xFFFC4A1A), Color(0xFFF7B733)), "LK"),
    ChatPreview("8", "Новости технологий", "Релизы мобильных ОС 2026", "Чт", 0, listOf(Color(0xFF396AFC), Color(0xFF2948FF)), "НТ"),
    ChatPreview("9", "Архив проектов", "Старые репозитории и заметки", "Ср", 0, listOf(Color(0xFF8E2DE2), Color(0xFF4A00E0)), "АП"),
    ChatPreview("10", "Бот уведомлений", "Сборка GitHub Actions завершена успешно", "Вт", 2, listOf(Color(0xFF00B4DB), Color(0xFF0083B0)), "БУ")
)

// Компонент Liquid Glass (iOS 26 style)
@Composable
fun GlassContainer(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(24.dp),
    glassAlpha: Float = 0.14f,
    borderAlpha: Float = 0.28f,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = glassAlpha + 0.06f),
                        Color.White.copy(alpha = glassAlpha)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = borderAlpha),
                        Color.White.copy(alpha = 0.05f),
                        Color(0xFF3390EC).copy(alpha = 0.25f)
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

// Зона статус-бара с часами: тап по часам / верхней зоне статус-бара плавно скроллит вверх (как в iOS)
@Composable
fun StatusBarClockTapZone(
    onScrollToTop: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var currentTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTime = formatter.format(Date())
            delay(1000L)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsTopHeight(WindowInsets.statusBars)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onScrollToTop()
            }
    )
}

// Интерактивный стеклянный бейдж с часами в шапке (при нажатии также скроллит в самый верх)
@Composable
fun InteractiveClockPill(
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var currentTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTime = formatter.format(Date())
            delay(1000L)
        }
    }

    GlassContainer(
        modifier = Modifier.clickable {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        },
        shape = CircleShape,
        glassAlpha = 0.22f,
        borderAlpha = 0.35f
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = currentTime,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Наверх",
                tint = Color(0xFF60A5FA),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

// Динамический анимированный фон (Mesh-градиент в стиле iOS 26)
@Composable
fun AnimatedLiquidBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "bg_transition")
    val offset1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 120f,
        animationSpec = infiniteRepeatable(
            animation = tween(9000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blob1"
    )
    val offset2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -140f,
        animationSpec = infiniteRepeatable(
            animation = tween(11000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blob2"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B14))
    ) {
        Box(
            modifier = Modifier
                .size(340.dp)
                .offset(x = (-60 + offset1).dp, y = (40 + offset1 * 0.5f).dp)
                .blur(90.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF1D4ED8).copy(alpha = 0.45f), Color.Transparent)
                    ),
                    CircleShape
                )
        )
        Box(
            modifier = Modifier
                .size(380.dp)
                .align(Alignment.BottomEnd)
                .offset(x = (80 + offset2).dp, y = (-80 + offset2 * 0.4f).dp)
                .blur(100.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF7C3AED).copy(alpha = 0.38f), Color.Transparent)
                    ),
                    CircleShape
                )
        )
        Box(
            modifier = Modifier
                .size(260.dp)
                .align(Alignment.Center)
                .offset(x = offset2.dp, y = offset1.dp)
                .blur(85.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF0EA5E9).copy(alpha = 0.25f), Color.Transparent)
                    ),
                    CircleShape
                )
        )
    }
}

@Composable
fun TelegramGlassApp() {
    val navController = rememberNavController()

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedLiquidBackground()

        // Навигация с iOS 26 физикой переходов (Spring-физика + параллакс + масштабирование)
        NavHost(
            navController = navController,
            startDestination = "chats",
            enterTransition = {
                slideInHorizontally(
                    initialOffsetX = { fullWidth -> fullWidth },
                    animationSpec = spring(
                        dampingRatio = 0.86f,
                        stiffness = 380f
                    )
                ) + fadeIn(animationSpec = tween(220))
            },
            exitTransition = {
                slideOutHorizontally(
                    targetOffsetX = { fullWidth -> -(fullWidth * 0.28f).toInt() },
                    animationSpec = spring(
                        dampingRatio = 0.86f,
                        stiffness = 380f
                    )
                ) + scaleOut(
                    targetScale = 0.94f,
                    animationSpec = tween(300)
                ) + fadeOut(animationSpec = tween(260))
            },
            popEnterTransition = {
                slideInHorizontally(
                    initialOffsetX = { fullWidth -> -(fullWidth * 0.28f).toInt() },
                    animationSpec = spring(
                        dampingRatio = 0.86f,
                        stiffness = 380f
                    )
                ) + scaleIn(
                    initialScale = 0.94f,
                    animationSpec = tween(300)
                ) + fadeIn(animationSpec = tween(220))
            },
            popExitTransition = {
                slideOutHorizontally(
                    targetOffsetX = { fullWidth -> fullWidth },
                    animationSpec = spring(
                        dampingRatio = 0.86f,
                        stiffness = 380f
                    )
                ) + fadeOut(animationSpec = tween(240))
            }
        ) {
            composable("chats") {
                ChatListScreen(
                    chats = sampleChats,
                    onChatClick = { chat ->
                        navController.navigate("chat/${chat.id}/${chat.title}")
                    }
                )
            }
            composable(
                route = "chat/{chatId}/{chatTitle}",
                arguments = listOf(
                    navArgument("chatId") { type = NavType.StringType },
                    navArgument("chatTitle") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val title = backStackEntry.arguments?.getString("chatTitle") ?: "Чат"
                ChatDetailScreen(
                    chatTitle = title,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
fun ChatListScreen(
    chats: List<ChatPreview>,
    onChatClick: (ChatPreview) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val scrollToTop: () -> Unit = {
        coroutineScope.launch {
            listState.animateScrollToItem(0)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Парящий Glass Header в стиле iOS 26
            GlassContainer(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                glassAlpha = 0.16f
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Telegram Glass",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        // Интерактивные часы: нажатие скроллит список чатов в самый верх
                        InteractiveClockPill(onClick = scrollToTop)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Стеклянная строка поиска
                    GlassContainer(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        glassAlpha = 0.1f,
                        borderAlpha = 0.18f
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (searchQuery.isEmpty()) "Поиск сообщений и чатов..." else searchQuery,
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Список чатов в стеклянных карточках
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                items(chats) { chat ->
                    GlassContainer(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onChatClick(chat) },
                        shape = RoundedCornerShape(22.dp),
                        glassAlpha = 0.12f,
                        borderAlpha = 0.22f
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(chat.avatarColor)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = chat.initials,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = chat.title,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = chat.time,
                                        color = Color.White.copy(alpha = 0.55f),
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = chat.subtitle,
                                        color = Color.White.copy(alpha = 0.72f),
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (chat.unreadCount > 0) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .background(Color(0xFF3390EC))
                                                .padding(horizontal = 8.dp, vertical = 2.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = chat.unreadCount.toString(),
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Невидимая зона поверх системных часов в статус-баре (iOS Scroll-to-Top жест)
        StatusBarClockTapZone(onScrollToTop = scrollToTop)
    }
}

@Composable
fun ChatDetailScreen(
    chatTitle: String,
    onBack: () -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val messages = remember {
        mutableStateListOf(
            ChatMessage("1", "Добро пожаловать в интерфейс Liquid Glass!", "14:15", false),
            ChatMessage("2", "Попробуй нажать на часы вверху экрана или в области статус-бара.", "14:16", false),
            ChatMessage("3", "Сработает фирменный iOS-жест плавной прокрутки в самый верх!", "14:16", false),
            ChatMessage("4", "Также поддерживается пружинная физика переходов iOS 26.", "14:17", false),
            ChatMessage("5", "Прозрачные панели с градиентными бликами и световыми рамками.", "14:18", false),
            ChatMessage("6", "Анимация появления новых сообщений при отправке.", "14:18", false),
            ChatMessage("7", "Выглядит супер! И собирается прямо в GitHub Actions.", "14:19", true),
            ChatMessage("8", "Никаких лишних зависимостей и ошибок при сборке.", "14:20", true)
        )
    }

    val scrollToTop: () -> Unit = {
        coroutineScope.launch {
            listState.animateScrollToItem(0)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Верхняя стеклянная панель чата
            GlassContainer(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                shape = RoundedCornerShape(26.dp),
                glassAlpha = 0.18f
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад",
                            tint = Color.White
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF3390EC), Color(0xFF6366F1)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = chatTitle.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = chatTitle,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "в сети",
                            color = Color(0xFF60A5FA),
                            fontSize = 12.sp
                        )
                    }
                    // Интерактивные часы в шапке чата для быстрого скролла к первому сообщению
                    InteractiveClockPill(onClick = scrollToTop)
                    Spacer(modifier = Modifier.width(4.dp))
                }
            }

            // Лента сообщений с анимацией появления новых пузырей
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    AnimatedVisibility(
                        visible = true,
                        enter = scaleIn(
                            initialScale = 0.85f,
                            animationSpec = spring(dampingRatio = 0.75f, stiffness = 400f)
                        ) + fadeIn()
                    ) {
                        MessageBubble(msg)
                    }
                }
            }

            // Нижняя стеклянная панель ввода (Floating Glass Pill)
            GlassContainer(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                shape = RoundedCornerShape(30.dp),
                glassAlpha = 0.18f,
                borderAlpha = 0.32f
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { }) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "Вложение",
                            tint = Color.White.copy(alpha = 0.7f)
                        )
                    }
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text("Сообщение...", color = Color.White.copy(alpha = 0.5f))
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
                                messages.add(
                                    ChatMessage(
                                        id = System.currentTimeMillis().toString(),
                                        text = inputText.trim(),
                                        time = formatter.format(Date()),
                                        isMine = true
                                    )
                                )
                                inputText = ""
                                coroutineScope.launch {
                                    listState.animateScrollToItem(messages.lastIndex)
                                }
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF3390EC), Color(0xFF2563EB))
                                )
                            )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Отправить",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Невидимая зона поверх системных часов в статус-баре (iOS Scroll-to-Top жест)
        StatusBarClockTapZone(onScrollToTop = scrollToTop)
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val alignment = if (message.isMine) Alignment.End else Alignment.Start
    val bubbleShape = if (message.isMine) {
        RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp)
    } else {
        RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 290.dp)
                .clip(bubbleShape)
                .background(
                    if (message.isMine) {
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF3390EC).copy(alpha = 0.75f),
                                Color(0xFF1D4ED8).copy(alpha = 0.85f)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.18f),
                                Color.White.copy(alpha = 0.11f)
                            )
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = if (message.isMine) 0.35f else 0.22f),
                    shape = bubbleShape
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.time,
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
